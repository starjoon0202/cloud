This folder contains files which are no longer used, but for historical
reasons are still present.
 
No updates are issued for these files anymore.