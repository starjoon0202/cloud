#!/bin/sh
python3.4 service_function.py --type fw --host 0.0.0.0 --port 40001
